

void PerceptionClustering::scanScene(pcl::PointCloud<pcl::PointXYZRGB>::Ptr& input_pcPtr, int degree_start, int degree_end)
{
 // get the height of the head pose and look at the origin at half of the head height
 pcl::PointCloud<pcl::PointXYZRGB>::Ptr sum_pcPtr(new pcl::PointCloud<pcl::PointXYZRGB>());
 geometry_msgs::PointStamped pt_head;
 geometry_msgs::TransformStamped transformStamped;
 geometry_msgs::TransformStamped initial_transformStamped;
 tf::Transform initial_transform;
 // keep the initial transformation to transform the point cloud into the same frame
 transform_frame(pt_head, 0.0, 0.0, 0.0, "base_link", "head_camera_rgb_optical_frame");
 ROS_INFO("the head position point: %f, %f, %f", pt_head.point.x, pt_head.point.y, pt_head.point.z);
 head_lookat(1.0, 0.0, pt_head.point.z / 2, "base_link");
 // the time out is for the head to slide into the exact pose
 ros::Duration(4.0).sleep();

 initial_transformStamped = lookup_transform( "head_camera_rgb_optical_frame", "base_link");
 tf::transformMsgToTF(initial_transformStamped.transform, initial_transform);
 int full_range = degree_end - degree_start;
 int sampling_time = full_range / 30 + 1;

 for (int i = 0; i < sampling_time; i++)
 {

   double cur_degree = degree_start + i*30;
   ROS_INFO("current degree %f, point %f, %f, %f ", cur_degree, 1.0, sin( cur_degree * PI / 180.0 ), pt_head.point.z);
   head_lookat(1.0, sin( cur_degree * PI / 180.0 ), pt_head.point.z / 2, "base_link");
   ros::Duration(5.0).sleep();

    //the transformation is to transform the point cloud into the same frame
   transformStamped = lookup_transform("base_link", "head_camera_rgb_optical_frame");
   tf::Transform transform;
   tf::transformMsgToTF(transformStamped.transform, transform);
   pcl::PointCloud<pcl::PointXYZRGB>::Ptr transformed_cloud (new pcl::PointCloud<pcl::PointXYZRGB> ());
   pcl_ros::transformPointCloud (*input_pcPtr_, *transformed_cloud, transform);
   ros::Duration(2.0).sleep();
   // combine the transformed point cloud together to get a wider view of the scene
   *sum_pcPtr += *transformed_cloud;

 }
 head_lookat(1.0, 0.0, pt_head.point.z / 2, "base_link");
 ros::Duration(3.0).sleep();
  pcl_ros::transformPointCloud (*sum_pcPtr, *input_pcPtr, initial_transform);

 ROS_INFO("finish scanning");
 ros::Duration(1.0).sleep();
}

void
PerceptionClustering::extract_boundingbox(pcl::PointCloud<pcl::PointXYZRGB>::Ptr object_pcPtr,
                                        shape_msgs::SolidPrimitive& primitive,
                                        geometry_msgs::Pose& pose)
{
 ApproxMVBB::Matrix3Dyn mvbb_points(3, object_pcPtr->points.size());
 for (int i = 0; i < object_pcPtr->points.size(); i++)
 {
   mvbb_points.col(i) << object_pcPtr->points[i].x, object_pcPtr->points[i].y, object_pcPtr->points[i].z;
 }

 ApproxMVBB::OOBB oobb = ApproxMVBB::approximateMVBB(mvbb_points, 0.001, object_pcPtr->points.size(), 5, 0, 5);
 // store the position of the object
 float position_x =(oobb.m_maxPoint.x() + oobb.m_minPoint.x()) / 2;
 float position_y =(oobb.m_maxPoint.y() + oobb.m_minPoint.y()) / 2;
 float position_z =(oobb.m_maxPoint.z() + oobb.m_minPoint.z()) / 2;
 Eigen::Vector3f oobb_position(position_x, position_y, position_z);

 Eigen::Quaternionf rot(oobb.m_q_KI.w(), oobb.m_q_KI.x(), oobb.m_q_KI.y(), oobb.m_q_KI.z());
 oobb_position = rot.matrix()*oobb_position;
 pose.position.x = oobb_position.x();
 pose.position.y = oobb_position.y();
 pose.position.z = oobb_position.z();

 // get the orientation of the object
 pose.orientation.x = rot.x();
 pose.orientation.y = rot.y();
 pose.orientation.z = rot.z();
 pose.orientation.w = rot.w();

 // store the width, height, and depth of the object
 primitive.dimensions.push_back(oobb.m_maxPoint.x() - oobb.m_minPoint.x());
 primitive.dimensions.push_back(oobb.m_maxPoint.y() - oobb.m_minPoint.y());
 primitive.dimensions.push_back(oobb.m_maxPoint.z() - oobb.m_minPoint.z());

 ROS_INFO("in exract_boundingbox, max point: %d, %d, %d, %d", oobb.m_maxPoint[0], oobb.m_maxPoint[1], oobb.m_maxPoint[2]);
}
