Add to fetch_gazebo
